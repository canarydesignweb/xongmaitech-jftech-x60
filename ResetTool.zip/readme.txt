1. Config.ini allows you to change the reset setting.
2. Win 7 requires to enable Telnet.
3. After reset, you need to reboot the device.